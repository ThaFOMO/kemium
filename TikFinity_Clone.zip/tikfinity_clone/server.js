const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const { WebcastPushConnection } = require('tiktok-live-connector');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

const tiktokUsername = 'YOUR_USERNAME'; // replace with your TikTok username
let tiktok = new WebcastPushConnection(tiktokUsername);

tiktok.connect().then(state => {
  console.log(`Connected to roomId: ${state.roomId}`);
}).catch(err => {
  console.error('Failed to connect', err);
});

tiktok.on('follow', data => {
  console.log(`New follow from ${data.uniqueId}`);
  io.emit('follow', { username: data.uniqueId });
});

server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
